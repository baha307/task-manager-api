from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required

from api.models import Task



def home(request):
    return render(request, "home.html")



def register(request):

    if request.method == "POST":

        username = request.POST["username"]
        email = request.POST["email"]
        password = request.POST["password"]

        if User.objects.filter(username=username).exists():

            messages.error(request, "Username already exists")
            return redirect("register")


        user = User.objects.create_user(
            username=username,
            email=email,
            password=password
        )

        user.save()

        messages.success(
            request,
            "Registration successful. Please login."
        )

        return redirect("login")


    return render(request, "register.html")



def login_view(request):

    if request.method == "POST":

        username = request.POST["username"]
        password = request.POST["password"]


        user = authenticate(
            request,
            username=username,
            password=password
        )


        if user is not None:

            login(request, user)

            return redirect("dashboard")


        else:

            messages.error(
                request,
                "Invalid username or password"
            )


    return render(request, "login.html")



@login_required
def dashboard(request):

    tasks = Task.objects.filter(
        user=request.user
    )

    context = {
        "tasks": tasks
    }

    return render(
        request,
        "dashboard.html",
        context
    )

@login_required
def add_task(request):

    if request.method == "POST":

        title = request.POST["title"]
        description = request.POST["description"]
        status = request.POST["status"]


        Task.objects.create(
            title=title,
            description=description,
            status=status,
            user=request.user
        )


        messages.success(
            request,
            "Task added successfully"
        )


        return redirect("dashboard")


    return render(request, "add_task.html")

@login_required
def edit_task(request, id):

    task = Task.objects.get(
        id=id,
        user=request.user
    )


    if request.method == "POST":

        task.title = request.POST["title"]
        task.description = request.POST["description"]
        task.status = request.POST["status"]

        task.save()


        messages.success(
            request,
            "Task updated successfully"
        )


        return redirect("dashboard")


    return render(
        request,
        "edit_task.html",
        {
            "task": task
        }
    )



@login_required
def delete_task(request, id):

    task = Task.objects.get(
        id=id,
        user=request.user
    )


    task.delete()


    messages.success(
        request,
        "Task deleted successfully"
    )


    return redirect("dashboard")