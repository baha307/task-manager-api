from django.urls import path
from . import views


urlpatterns = [

    path(
        "",
        views.home,
        name="home"
    ),


    path(
        "register/",
        views.register,
        name="register"
    ),


    path(
        "login/",
        views.login_view,
        name="login"
    ),


    path(
        "dashboard/",
        views.dashboard,
        name="dashboard"
    ),
        path(
        "add/",
        views.add_task,
        name="add_task"
    ),

    path(
    "edit/<int:id>/",
    views.edit_task,
    name="edit_task"
),


path(
    "delete/<int:id>/",
    views.delete_task,
    name="delete_task"
),

]